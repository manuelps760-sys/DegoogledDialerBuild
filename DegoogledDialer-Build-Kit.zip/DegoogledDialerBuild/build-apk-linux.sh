#!/usr/bin/env bash
set -euo pipefail

# One-shot builder for Debian/Ubuntu x86_64 or ARM64 Linux hosts.
# Requires internet access. It installs Gradle 8.2.1 and Android SDK API 34,
# then builds the debug APK from this project directory.

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOOLS_DIR="${DIALER_BUILD_TOOLS_DIR:-$HOME/.cache/degoogled-dialer-build-tools}"
SDK_ROOT="${ANDROID_HOME:-$HOME/Android/Sdk}"
GRADLE_VERSION="8.2.1"
CMDLINE_TOOLS_VERSION="15859902"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-${CMDLINE_TOOLS_VERSION}_latest.zip"
CMDLINE_TOOLS_SHA256="4e4c464f145a7512b57d088ac6c278c03c9eea610886b35a5e0804e74eedf583"

if [[ ! -f /etc/debian_version ]]; then
  echo "This script supports Debian/Ubuntu Linux. For another OS, use Android Studio or the GitHub Actions workflow." >&2
  exit 1
fi
if ! command -v apt-get >/dev/null 2>&1; then
  echo "apt-get was not found; use setup-build-tools-linux.sh on Debian/Ubuntu or Android Studio." >&2
  exit 1
fi

if [[ "$(id -u)" -eq 0 ]]; then SUDO=""; else SUDO="sudo"; fi
$SUDO apt-get update
$SUDO apt-get install -y openjdk-17-jdk curl unzip ca-certificates

# Prefer Java 17 because Android Gradle Plugin 8.2 requires JDK 17.
JAVAC_17="$(find -L /usr/lib/jvm -type f -path '*java-17*/bin/javac' -print -quit 2>/dev/null || true)"
if [[ -z "$JAVAC_17" ]]; then
  echo "Could not locate javac from OpenJDK 17 after installation." >&2
  exit 1
fi
export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$JAVAC_17")")")"
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
mkdir -p "$TOOLS_DIR" "$SDK_ROOT/cmdline-tools"

# Download and install the Gradle version compatible with AGP 8.2.x.
GRADLE_DIR="$TOOLS_DIR/gradle-${GRADLE_VERSION}"
if [[ ! -x "$GRADLE_DIR/bin/gradle" ]]; then
  TMP_GRADLE="$(mktemp -d)"
  trap 'rm -rf "$TMP_GRADLE"' EXIT
  curl --fail --location --retry 3 "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -o "$TMP_GRADLE/gradle.zip"
  unzip -q "$TMP_GRADLE/gradle.zip" -d "$TOOLS_DIR"
fi
export PATH="$GRADLE_DIR/bin:$PATH"

# Install current Android CLI tools if sdkmanager is not already installed.
SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
if [[ ! -x "$SDKMANAGER" ]]; then
  TMP_SDK="$(mktemp -d)"
  trap 'rm -rf "${TMP_GRADLE:-}" "${TMP_SDK:-}"' EXIT
  curl --fail --location --retry 3 "$CMDLINE_TOOLS_URL" -o "$TMP_SDK/cmdline-tools.zip"
  echo "$CMDLINE_TOOLS_SHA256  $TMP_SDK/cmdline-tools.zip" | sha256sum -c -
  unzip -q "$TMP_SDK/cmdline-tools.zip" -d "$TMP_SDK"
  mkdir -p "$SDK_ROOT/cmdline-tools/latest"
  cp -a "$TMP_SDK/cmdline-tools/." "$SDK_ROOT/cmdline-tools/latest/"
  rm -rf "$TMP_SDK"
  SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
fi

# Accept the Android SDK licenses, then fetch only the packages needed to build.
set +o pipefail
yes | "$SDKMANAGER" --sdk_root="$SDK_ROOT" --licenses >/dev/null
set -o pipefail
"$SDKMANAGER" --sdk_root="$SDK_ROOT" \
  "platform-tools" "platforms;android-34" "build-tools;34.0.0"

cd "$PROJECT_DIR"
gradle --no-daemon --stacktrace assembleDebug
APK="$PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -s "$APK" ]]; then
  echo "Gradle finished without producing the expected APK: $APK" >&2
  exit 1
fi
cp "$APK" "$PROJECT_DIR/DegoogledDialer-debug.apk"
echo
echo "BUILD SUCCESSFUL"
echo "APK: $PROJECT_DIR/DegoogledDialer-debug.apk"
echo "SHA-256: $(sha256sum "$PROJECT_DIR/DegoogledDialer-debug.apk" | awk '{print $1}')"
