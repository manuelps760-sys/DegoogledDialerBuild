# Degoogled Dialer — build kit

This package contains the Android project source and build helpers for the `org.degoogled.dialer` application.

## Build on Debian or Ubuntu Linux

A Linux computer with internet access can build the debug APK in one command. From this project folder, run:

```bash
bash build-apk-linux.sh
```

The script installs OpenJDK 17, downloads Gradle 8.2.1 and Google's Android command-line tools, installs Android API 34/build-tools 34.0.0, accepts the SDK licenses, and runs `assembleDebug`. It creates:

- `app/build/outputs/apk/debug/app-debug.apk`
- `DegoogledDialer-debug.apk` (a convenient copy in the project root)

It needs `sudo` for the Debian/Ubuntu package installation and requires internet access. Review the script before running it.

## Build with GitHub Actions

The `.github/workflows/build-apk.yml` workflow builds the APK and uploads it as an artifact when run on GitHub. Put the project contents at the root of a GitHub repository, push to `main` or `master`, or run the workflow manually from the repository's **Actions** tab. Download the `DegoogledDialer-debug` artifact from the completed workflow.

## Android Studio

Open this folder as a project in Android Studio with JDK 17 configured. Install Android SDK Platform 34 and Build Tools 34.0.0, then run the `assembleDebug` Gradle task.

## Notes

- Namespace/application ID: `org.degoogled.dialer`
- Minimum Android SDK: 26 (Android 8.0)
- Target/compile SDK: 34 (Android 14)
- This is a **debug** build, not a Play Store release-signed APK.
- Building does not prove every feature works on a real phone. Telecom/default-dialer behavior, carrier-controlled cellular calling, microphone routing, SIP/SRTP interoperability, and radio diagnostics require device testing and permissions. A third-party app cannot bypass Android or carrier restrictions to control all baseband functionality.
