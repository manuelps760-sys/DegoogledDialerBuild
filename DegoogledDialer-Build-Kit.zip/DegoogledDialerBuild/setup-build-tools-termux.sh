#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

# Install build prerequisites on Termux. Run this on the Android phone, not in ChatGPT.
if ! command -v pkg >/dev/null 2>&1; then
  echo 'This script is for Termux on Android.' >&2
  exit 1
fi
pkg update
pkg install -y openjdk-17 gradle android-tools unzip

# Android SDK packages are not available from every Termux repository. Check for SDK manager.
if command -v sdkmanager >/dev/null 2>&1; then
  SDKMANAGER="$(command -v sdkmanager)"
elif [ -x "$HOME/android-sdk/cmdline-tools/latest/bin/sdkmanager" ]; then
  SDKMANAGER="$HOME/android-sdk/cmdline-tools/latest/bin/sdkmanager"
else
  cat <<'MSG'
Gradle and Java are installed, but sdkmanager was not found.
Install Android command-line tools and set ANDROID_HOME to the SDK directory,
then install platform 34 and build-tools 34.0.0 with sdkmanager:
  sdkmanager --licenses
  sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
For Termux, Android SDK command-line tools may need a Linux-compatible SDK setup;
if sdkmanager cannot run on-device, build with Android Studio on a computer.
MSG
  exit 2
fi

export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")"
export ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
"$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses || true
"$SDKMANAGER" --sdk_root="$ANDROID_HOME" "platform-tools" "platforms;android-34" "build-tools;34.0.0"

cat <<MSG
Build prerequisites setup finished.
To build the project, enter its directory and run:
  export ANDROID_HOME="$ANDROID_HOME"
  export ANDROID_SDK_ROOT="\$ANDROID_HOME"
  gradle --no-daemon assembleDebug
MSG
