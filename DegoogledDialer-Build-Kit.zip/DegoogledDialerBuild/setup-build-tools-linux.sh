#!/usr/bin/env bash
set -euo pipefail
# Compatibility entry point: installs the build tools and builds the debug APK.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$SCRIPT_DIR/build-apk-linux.sh" "$@"
