# Degoogled SIPS / SRTP Phone Dialer & Developer Suite (v5.0)

A fully operational, degoogled Android Phone Dialer and VoIP/Cellular Telephony suite built on native AOSP framework APIs (TelecomManager, InCallService). Operates entirely independent of Google Play Services (GMS).

## Key Features & Capabilities

1. Real-Time Live In-Call Voice Transformer
- Live DSP Engine (`VoiceChanger`): Transforms 16-bit PCM microphone audio in real time during active calls before G.711 encoding and SRTP encryption.
- 5 Selectable Voice Effects:
  - Normal Voice (Original Audio)
  - Deep / Low Pitch (Pitch Down 👺)
  - Helium / High Pitch (Pitch Up 🎈)
  - Cyber Robot Modulation (180Hz Ring Modulation 🤖)
  - Anonymizer Filter (Step Quantization Distortion 
- In-Call Instant Switching: Change voice effects on the fly during live calls using interactive control buttons on the active call HUD screen.

2. Secure VoIP Protocol Engines
- RFC 3261 SIPS (SIP over TLS 1.3): Built-in SSLSocket transport engine for encrypted signaling over port 5061 with Digest MD5 authentication.
- RFC 3711 SRTP (Secure RTP) Media Stream: Real-time PCM microphone capture with G.711 PCMU/PCMA codec encoding and AES-128 payload encryption.
- RFC 4568 SDES Key Exchange: Negotiates SRTP crypto parameters in Session Description Protocol (SDP) offers/answers.

3. Developer Settings & Network Diagnostics
- Secret Code Interceptor (*#*#338#*#*): Triggers developer tools when typing *#*#338#*#* or *#*#DEV#*#* into the dialer keypad.
- Live In-Call Security & Voice HUD: Real-time HUD displaying active encryption status, active voice effect, codec type, jitter (ms), packet loss %, and encrypted packet counts.
- Wireshark PCAP Packet Dumper (PcapLogger): Generates binary .pcap capture files directly on device storage for offline network analysis.
- Cellular Radio Diagnostics (RadioDiagnosticsActivity): Live view for RSRP signal strength (dBm), RSRQ quality, Cell ID, VoLTE/Vo5G provisioning, and IMSI Catcher Guard.

4. Native Phone Features & Privacy Hardening
- In-Call Local Audio Recorder (CallRecorder): Record active voice calls directly to uncompressed 16-bit WAV files locally on device storage.
- Local Contacts & Call Logs (ContactsDbHelper): SQLite database for offline contacts and call history management without Google Cloud sync.
- DTMF Tone Generator (DtmfPlayer): Audio feedback for keypad digits and in-call touch tones.
- SIP Error Simulation: Inject SIP status responses (404 Not Found, 486 User Busy, 503 Service Unavailable) to test application error recovery.
- Privacy Controls Audit: Built-in guidance for disabling 2G radio connectivity (preventing Stingray attacks) and checking call forwarding rules (*#67#).

## Building & Running

1. Extract degoogled-dialer-app-v5.zip.
2. Open the project in Android Studio (Hedgehog 2023.1.1+).
3. Target SDK: 34 (Android 14) / Minimum SDK: 26 (Android 8.0).
4. Run on an Android device or emulator.
5. Set as Default Phone App under Settings > Apps > Default Apps > Phone app.
