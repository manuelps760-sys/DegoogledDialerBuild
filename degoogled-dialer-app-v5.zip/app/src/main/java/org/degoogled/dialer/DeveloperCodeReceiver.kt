package org.degoogled.dialer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class DeveloperCodeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "android.provider.Telephony.SECRET_CODE") {
            val devIntent = Intent(context, DeveloperSettingsActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            context.startActivity(devIntent)
        }
    }
}
