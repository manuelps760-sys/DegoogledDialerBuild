package org.degoogled.dialer

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/**
 * Binary Wireshark-Compatible .pcap Packet Dumper Writer.
 */
class PcapLogger(context: Context, filename: String) {

    private val pcapFile: File = File(context.filesDir, filename)
    private var outputStream: OutputStream? = null

    init {
        outputStream = FileOutputStream(pcapFile, false)
        writeGlobalHeader()
    }

    private fun writeGlobalHeader() {
        val globalHeader = byteArrayOf(
            0xd4.toByte(), 0xc3.toByte(), 0xb2.toByte(), 0xa1.toByte(), // Magic Number
            0x02.toByte(), 0x00.toByte(), // Major Version 2
            0x04.toByte(), 0x00.toByte(), // Minor Version 4
            0x00.toByte(), 0x00.toByte(), 0x00.toByte(), 0x00.toByte(), // Timezone GMT
            0x00.toByte(), 0x00.toByte(), 0x00.toByte(), 0x00.toByte(), // Accuracy
            0xff.toByte(), 0xff.toByte(), 0x00.toByte(), 0x00.toByte(), // Max Packet SnapLen (65535)
            101.toByte(), 0x00.toByte(), 0x00.toByte(), 0x00.toByte()  // LinkType = RAW / IP (101)
        )
        outputStream?.write(globalHeader)
        outputStream?.flush()
    }

    fun logPacket(payload: ByteArray, length: Int, remoteIp: String, remotePort: Int) {
        val nowMs = System.currentTimeMillis()
        val sec = (nowMs / 1000).toInt()
        val usec = ((nowMs % 1000) * 1000).toInt()

        val packetHeader = ByteArray(16)
        packetHeader[0] = (sec and 0xFF).toByte()
        packetHeader[1] = ((sec shr 8) and 0xFF).toByte()
        packetHeader[2] = ((sec shr 16) and 0xFF).toByte()
        packetHeader[3] = ((sec shr 24) and 0xFF).toByte()

        packetHeader[4] = (usec and 0xFF).toByte()
        packetHeader[5] = ((usec shr 8) and 0xFF).toByte()
        packetHeader[6] = ((usec shr 16) and 0xFF).toByte()
        packetHeader[7] = ((usec shr 24) and 0xFF).toByte()

        packetHeader[8] = (length and 0xFF).toByte()
        packetHeader[9] = ((length shr 8) and 0xFF).toByte()
        packetHeader[10] = ((length shr 16) and 0xFF).toByte()
        packetHeader[11] = ((length shr 24) and 0xFF).toByte()

        packetHeader[12] = (length and 0xFF).toByte()
        packetHeader[13] = ((length shr 8) and 0xFF).toByte()
        packetHeader[14] = ((length shr 16) and 0xFF).toByte()
        packetHeader[15] = ((length shr 24) and 0xFF).toByte()

        outputStream?.write(packetHeader)
        outputStream?.write(payload, 0, length)
        outputStream?.flush()
    }

    fun close() {
        outputStream?.close()
    }
}
