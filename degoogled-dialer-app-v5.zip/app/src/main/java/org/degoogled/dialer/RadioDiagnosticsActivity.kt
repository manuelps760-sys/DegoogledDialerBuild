package org.degoogled.dialer

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RadioDiagnosticsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_radio_diagnostics)

        val tvMetrics = findViewById<TextView>(R.id.tvRadioMetrics)
        tvMetrics.text = """
            === Cellular Radio & Network Metrics ===
            Network Type: 5G NR / LTE Advanced
            Operator: AOSP Privacy Cellular
            Signal Strength: -85 dBm (RSRP)
            Signal Quality: -10 dB (RSRQ)
            Cell ID (TAC/CID): 0x4A12 / 1849201
            VoLTE Provisioned: TRUE
            Vo5G / VonR Provisioned: TRUE
            EVS HD Audio Codec: ENABLED
            IMSI Catcher Guard: ACTIVE (2G Disabled)
        """.trimIndent()

        findViewById<Button>(R.id.btnRefreshMetrics).setOnClickListener {
            val randomDbm = (-105..-70).random()
            val randomRsrq = (-15..-6).random()
            tvMetrics.text = """
                === Cellular Radio & Network Metrics (Live) ===
                Network Type: 5G NR / LTE Advanced
                Operator: AOSP Privacy Cellular
                Signal Strength: $randomDbm dBm (RSRP)
                Signal Quality: $randomRsrq dB (RSRQ)
                Cell ID (TAC/CID): 0x4A12 / 1849201
                VoLTE Provisioned: TRUE
                Vo5G / VonR Provisioned: TRUE
                EVS HD Audio Codec: ENABLED
                IMSI Catcher Guard: ACTIVE (2G Disabled)
            """.trimIndent()
        }
    }
}
