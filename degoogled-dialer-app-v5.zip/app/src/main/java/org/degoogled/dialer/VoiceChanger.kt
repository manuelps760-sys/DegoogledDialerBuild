package org.degoogled.dialer

import kotlin.math.PI
import kotlin.math.sin

/**
 * Real-Time DSP Voice Modification Engine for Live VoIP & Telephony Calls.
 * Processes 16-bit PCM audio samples in 20ms frame buffers at 8kHz.
 */
object VoiceChanger {

    enum class Mode(val label: String) {
        NORMAL("Normal Voice"),
        DEEP_PITCH("Deep / Low Pitch 👺"),
        HELIUM_PITCH("Helium / High Pitch 🎈"),
        ROBOT("Cyber Robot 🤖"),
        ANONYMIZER("Anonymizer Filter 🎭")
    }

    var currentMode: Mode = Mode.NORMAL
    private var carrierPhase = 0.0

    /**
     * Transforms 16-bit PCM buffer in real time before G.711 encoding and SRTP encryption.
     */
    fun processPcm(pcmBuffer: ShortArray, sampleCount: Int): ShortArray {
        if (currentMode == Mode.NORMAL || sampleCount <= 0) {
            return pcmBuffer
        }

        val outBuffer = ShortArray(sampleCount)

        when (currentMode) {
            Mode.DEEP_PITCH -> {
                // Pitch down (~0.72x scale) with linear interpolation
                val factor = 0.72
                var srcIdx = 0.0
                for (i in 0 until sampleCount) {
                    val idx0 = srcIdx.toInt().coerceIn(0, sampleCount - 1)
                    val idx1 = (idx0 + 1).coerceIn(0, sampleCount - 1)
                    val frac = srcIdx - idx0
                    val sample = ((1.0 - frac) * pcmBuffer[idx0] + frac * pcmBuffer[idx1]).toInt()
                    outBuffer[i] = sample.coerceIn(-32768, 32767).toShort()
                    srcIdx += factor
                    if (srcIdx >= sampleCount - 1) srcIdx %= (sampleCount - 1)
                }
            }

            Mode.HELIUM_PITCH -> {
                // Pitch up (~1.42x scale)
                val factor = 1.42
                var srcIdx = 0.0
                for (i in 0 until sampleCount) {
                    val idx0 = (srcIdx.toInt()) % sampleCount
                    val idx1 = (idx0 + 1) % sampleCount
                    val frac = srcIdx - srcIdx.toInt()
                    val sample = ((1.0 - frac) * pcmBuffer[idx0] + frac * pcmBuffer[idx1]).toInt()
                    outBuffer[i] = sample.coerceIn(-32768, 32767).toShort()
                    srcIdx += factor
                }
            }

            Mode.ROBOT -> {
                // Ring Modulation: 180Hz sine wave carrier wave
                val carrierFreq = 180.0
                val sampleRate = 8000.0
                val phaseStep = 2.0 * PI * carrierFreq / sampleRate

                for (i in 0 until sampleCount) {
                    val mod = sin(carrierPhase)
                    carrierPhase += phaseStep
                    if (carrierPhase > 2.0 * PI) carrierPhase -= 2.0 * PI
                    val sample = (pcmBuffer[i] * mod).toInt()
                    outBuffer[i] = sample.coerceIn(-32768, 32767).toShort()
                }
            }

            Mode.ANONYMIZER -> {
                // Step-quantization amplitude distortion
                val quantStep = 1024
                for (i in 0 until sampleCount) {
                    val original = pcmBuffer[i].toInt()
                    val quantized = (original / quantStep) * quantStep
                    outBuffer[i] = quantized.coerceIn(-32768, 32767).toShort()
                }
            }

            else -> {
                System.arraycopy(pcmBuffer, 0, outBuffer, 0, sampleCount)
            }
        }

        return outBuffer
    }
}
