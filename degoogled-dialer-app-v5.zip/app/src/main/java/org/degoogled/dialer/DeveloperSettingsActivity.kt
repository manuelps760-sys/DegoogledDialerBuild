package org.degoogled.dialer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DeveloperSettingsActivity : AppCompatActivity() {

    private lateinit var tvConsoleLog: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_developer_settings)

        tvConsoleLog = findViewById(R.id.tvConsoleLog)

        // SIPS / TLS Toggle
        val swTls = findViewById<Switch>(R.id.swSipsTls)
        swTls.isChecked = SipDebugManager.useTls
        swTls.setOnCheckedChangeListener { _, isChecked ->
            SipDebugManager.useTls = isChecked
            logConsole("🔒 SIPS / TLS 1.3 Signaling Toggled: $isChecked (Port ${if (isChecked) 5061 else 5060})")
        }

        // SRTP Media Encryption Toggle
        val swSrtp = findViewById<Switch>(R.id.swSrtpMedia)
        swSrtp.isChecked = SipDebugManager.useSrtp
        swSrtp.setOnCheckedChangeListener { _, isChecked ->
            SipDebugManager.useSrtp = isChecked
            logConsole("🔐 SRTP AES_CM_128_HMAC_SHA1_80 Payload Encryption Toggled: $isChecked")
        }

        // PCAP Capture Toggle
        val swPcap = findViewById<Switch>(R.id.swPcapDump)
        swPcap.isChecked = SipDebugManager.pcapEnabled
        swPcap.setOnCheckedChangeListener { _, isChecked ->
            SipDebugManager.pcapEnabled = isChecked
            logConsole("📦 PCAP Packet Capture Logging Toggled: $isChecked (File: sip_debug.pcap)")
        }

        // Audio Codec Selection
        val rgCodec = findViewById<RadioGroup>(R.id.rgCodec)
        rgCodec.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.rbPcmu) {
                SipDebugManager.selectedCodecPayloadType = 0
                logConsole("🎙️ Audio Codec set to PCMU (G.711 u-law / 64kbps)")
            } else if (checkedId == R.id.rbPcma) {
                SipDebugManager.selectedCodecPayloadType = 8
                logConsole("🎙️ Audio Codec set to PCMA (G.711 a-law / 64kbps)")
            }
        }

        // Voice Transformer Preset Selection
        val rgVoice = findViewById<RadioGroup>(R.id.rgVoicePreset)
        when (VoiceChanger.currentMode) {
            VoiceChanger.Mode.NORMAL -> rgVoice.check(R.id.rbVoiceNormal)
            VoiceChanger.Mode.DEEP_PITCH -> rgVoice.check(R.id.rbVoiceDeep)
            VoiceChanger.Mode.HELIUM_PITCH -> rgVoice.check(R.id.rbVoiceHelium)
            VoiceChanger.Mode.ROBOT -> rgVoice.check(R.id.rbVoiceRobot)
            VoiceChanger.Mode.ANONYMIZER -> rgVoice.check(R.id.rbVoiceAnon)
        }

        rgVoice.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.rbVoiceDeep -> VoiceChanger.Mode.DEEP_PITCH
                R.id.rbVoiceHelium -> VoiceChanger.Mode.HELIUM_PITCH
                R.id.rbVoiceRobot -> VoiceChanger.Mode.ROBOT
                R.id.rbVoiceAnon -> VoiceChanger.Mode.ANONYMIZER
                else -> VoiceChanger.Mode.NORMAL
            }
            VoiceChanger.currentMode = mode
            logConsole("🎙️ Live Voice Effect preset set to: ${mode.label}")
        }

        // SIP Error Response Simulation
        findViewById<Button>(R.id.btnSimulate404).setOnClickListener {
            logConsole("⚠️ [Error Simulation] Injected SIP 404 Not Found response")
        }
        findViewById<Button>(R.id.btnSimulate486).setOnClickListener {
            logConsole("⚠️ [Error Simulation] Injected SIP 486 User Busy response")
        }
        findViewById<Button>(R.id.btnSimulate503).setOnClickListener {
            logConsole("⚠️ [Error Simulation] Injected SIP 503 Service Unavailable response")
        }

        // Degoogled Security Audits
        findViewById<Button>(R.id.btnCallForwardCheck).setOnClickListener {
            logConsole("🛡️ Launching Call Forwarding Audit (*#67#)...")
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:*#67#")))
        }

        findViewById<Button>(R.id.btnSpamDbInspect).setOnClickListener {
            val db = SpamDbHelper(this)
            val res = db.isSpam("+18005550199")
            logConsole("🔍 Offline SQLite Spam Query (+18005550199): ${res ?: "Clean Number"}")
        }
    }

    private fun logConsole(msg: String) {
        tvConsoleLog.append("$msg\n")
    }
}
