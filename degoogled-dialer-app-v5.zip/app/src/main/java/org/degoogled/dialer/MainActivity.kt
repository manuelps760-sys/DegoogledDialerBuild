package org.degoogled.dialer

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.degoogled.dialer.sip.SipClient

class MainActivity : AppCompatActivity() {

    private lateinit var etDisplay: EditText
    private lateinit var etSipServer: EditText
    private lateinit var etSipUser: EditText
    private lateinit var etSipPass: EditText
    private lateinit var tvSipStatus: TextView
    private lateinit var btnRegister: Button
    private lateinit var btnCall: Button

    private var sipClient: SipClient? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etDisplay = findViewById(R.id.etNumberDisplay)
        etSipServer = findViewById(R.id.etSipServer)
        etSipUser = findViewById(R.id.etSipUser)
        etSipPass = findViewById(R.id.etSipPass)
        tvSipStatus = findViewById(R.id.tvSipStatus)
        btnRegister = findViewById(R.id.btnSipRegister)
        btnCall = findViewById(R.id.btnCall)

        sipClient = SipClient(this).apply {
            onStatusChanged = { status ->
                tvSipStatus.text = "Status: $status"
            }
            onCallConnected = {
                val intent = Intent(this@MainActivity, InCallActivity::class.java)
                startActivity(intent)
            }
        }

        setupKeypad()

        btnRegister.setOnClickListener {
            val server = etSipServer.text.toString()
            val user = etSipUser.text.toString()
            val pass = etSipPass.text.toString()

            sipClient?.startClient(server, user, pass, SipDebugManager.pcapEnabled, SipDebugManager.tlsEnabled)
        }

        btnCall.setOnClickListener {
            val target = etDisplay.text.toString()
            if (target.isEmpty()) {
                Toast.makeText(this, "Enter a number or extension", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            sipClient?.makeCall(target, SipDebugManager.selectedCodecPayloadType)
        }

        findViewById<Button>(R.id.btnLaunchDevSettings).setOnClickListener {
            startActivity(Intent(this, DeveloperSettingsActivity::class.java))
        }

        findViewById<Button>(R.id.btnLaunchRadioDiag).setOnClickListener {
            startActivity(Intent(this, RadioDiagnosticsActivity::class.java))
        }
    }

    private fun setupKeypad() {
        val buttonIds = intArrayOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9,
            R.id.btnStar, R.id.btnHash
        )

        for (id in buttonIds) {
            findViewById<Button>(id).setOnClickListener { v ->
                val digit = (v as Button).text.toString()
                etDisplay.append(digit)
                if (digit.isNotEmpty()) {
                    DtmfPlayer.playTone(digit[0])
                }
                checkSecretCodeTrigger(etDisplay.text.toString())
            }
        }

        findViewById<Button>(R.id.btnBackspace).setOnClickListener {
            val currentText = etDisplay.text.toString()
            if (currentText.isNotEmpty()) {
                etDisplay.setText(currentText.substring(0, currentText.length - 1))
            }
        }
    }

    private fun checkSecretCodeTrigger(input: String) {
        if (input == "*#*#338#*#*" || input == "*#*#DEV#*#*") {
            etDisplay.setText("")
            Toast.makeText(this, "Secret Code Triggered! Launching Developer Settings...", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, DeveloperSettingsActivity::class.java))
        } else if (input == "*#06#") {
            Toast.makeText(this, "IMEI: 869403049182301 / 869403049182302", Toast.LENGTH_LONG).show()
        } else if (input == "*#*#4636#*#*") {
            startActivity(Intent(this, RadioDiagnosticsActivity::class.java))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        sipClient?.stopClient()
    }
}
