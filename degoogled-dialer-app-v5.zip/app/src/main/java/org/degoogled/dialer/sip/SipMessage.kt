package org.degoogled.dialer.sip

import java.security.MessageDigest
import kotlin.random.Random

/**
 * RFC 3261 / RFC 4568 SIP Protocol Message Builder supporting SIPS (TLS) and SRTP SDES Crypto Negotiation.
 */
object SipMessage {

    fun generateCallId(): String {
        return "call-" + System.currentTimeMillis() + "-" + Random.nextInt(1000, 9999) + "@degoogled.dialer"
    }

    fun generateTag(): String {
        return "tag" + Random.nextInt(10000, 99999)
    }

    fun generateBranch(): String {
        return "z9hG4bK-" + Random.nextInt(100000, 999999)
    }

    /**
     * Build SIP REGISTER request (Supports sip: and sips: URIs).
     */
    fun buildRegister(
        server: String,
        user: String,
        localIp: String,
        localPort: Int,
        callId: String,
        cseq: Int,
        authHeader: String? = null,
        useTls: Boolean = true
    ): String {
        val scheme = if (useTls) "sips" else "sip"
        val proto = if (useTls) "TLS" else "UDP"
        val sb = StringBuilder()

        sb.append("REGISTER $scheme:$server SIP/2.0\r\n")
        sb.append("Via: SIP/2.0/$proto $localIp:$localPort;branch=${generateBranch()}\r\n")
        sb.append("Max-Forwards: 70\r\n")
        sb.append("From: <$scheme:$user@$server>;tag=${generateTag()}\r\n")
        sb.append("To: <$scheme:$user@$server>\r\n")
        sb.append("Call-ID: $callId\r\n")
        sb.append("CSeq: $cseq REGISTER\r\n")
        sb.append("Contact: <$scheme:$user@$localIp:$localPort;transport=${proto.lowercase()}>\r\n")
        sb.append("Expires: 3600\r\n")
        sb.append("User-Agent: DegoogledDialer/3.0 (AOSP SIPS+SRTP)\r\n")

        if (authHeader != null) {
            sb.append("Authorization: $authHeader\r\n")
        }

        sb.append("Content-Length: 0\r\n\r\n")
        return sb.toString()
    }

    /**
     * Build SIP INVITE request with SDP Offer for outgoing calls (Supports RTP/AVP and SRTP RTP/SAVP).
     */
    fun buildInvite(
        server: String,
        targetUser: String,
        fromUser: String,
        localIp: String,
        localPort: Int,
        rtpPort: Int,
        callId: String,
        cseq: Int,
        codecPt: Int = 0,
        useTls: Boolean = true,
        useSrtp: Boolean = true,
        srtpKey: String = "WfJ14a2I7L6Ua1b2c3d4e5f6g7h8i9j0k1l2m3n4"
    ): String {
        val scheme = if (useTls) "sips" else "sip"
        val proto = if (useTls) "TLS" else "UDP"
        val profile = if (useSrtp) "RTP/SAVP" else "RTP/AVP"
        val codecName = if (codecPt == 0) "PCMU" else "PCMA"

        val sdpSb = StringBuilder()
            .append("v=0\r\n")
            .append("o=- ${System.currentTimeMillis()} 1 IN IP4 $localIp\r\n")
            .append("s=Talk-Secure\r\n")
            .append("c=IN IP4 $localIp\r\n")
            .append("t=0 0\r\n")
            .append("m=audio $rtpPort $profile $codecPt 101\r\n")
            .append("a=rtpmap:$codecPt $codecName/8000\r\n")
            .append("a=rtpmap:101 telephone-event/8000\r\n")

        if (useSrtp) {
            sdpSb.append("a=crypto:1 AES_CM_128_HMAC_SHA1_80 inline:$srtpKey\r\n")
        }

        val sdp = sdpSb.toString()

        val sb = StringBuilder()
        sb.append("INVITE $scheme:$targetUser@$server SIP/2.0\r\n")
        sb.append("Via: SIP/2.0/$proto $localIp:$localPort;branch=${generateBranch()}\r\n")
        sb.append("Max-Forwards: 70\r\n")
        sb.append("From: <$scheme:$fromUser@$server>;tag=${generateTag()}\r\n")
        sb.append("To: <$scheme:$targetUser@$server>\r\n")
        sb.append("Call-ID: $callId\r\n")
        sb.append("CSeq: $cseq INVITE\r\n")
        sb.append("Contact: <$scheme:$fromUser@$localIp:$localPort;transport=${proto.lowercase()}>\r\n")
        sb.append("Content-Type: application/sdp\r\n")
        sb.append("User-Agent: DegoogledDialer/3.0 (AOSP SIPS+SRTP)\r\n")
        sb.append("Content-Length: ${sdp.length}\r\n\r\n")
        sb.append(sdp)

        return sb.toString()
    }

    fun buildAck(server: String, targetUser: String, fromUser: String, localIp: String, localPort: Int, callId: String, cseq: Int, useTls: Boolean = true): String {
        val scheme = if (useTls) "sips" else "sip"
        val proto = if (useTls) "TLS" else "UDP"
        val sb = StringBuilder()
        sb.append("ACK $scheme:$targetUser@$server SIP/2.0\r\n")
        sb.append("Via: SIP/2.0/$proto $localIp:$localPort;branch=${generateBranch()}\r\n")
        sb.append("Max-Forwards: 70\r\n")
        sb.append("From: <$scheme:$fromUser@$server>\r\n")
        sb.append("To: <$scheme:$targetUser@$server>\r\n")
        sb.append("Call-ID: $callId\r\n")
        sb.append("CSeq: $cseq ACK\r\n")
        sb.append("Content-Length: 0\r\n\r\n")
        return sb.toString()
    }

    fun buildBye(server: String, targetUser: String, fromUser: String, localIp: String, localPort: Int, callId: String, cseq: Int, useTls: Boolean = true): String {
        val scheme = if (useTls) "sips" else "sip"
        val proto = if (useTls) "TLS" else "UDP"
        val sb = StringBuilder()
        sb.append("BYE $scheme:$targetUser@$server SIP/2.0\r\n")
        sb.append("Via: SIP/2.0/$proto $localIp:$localPort;branch=${generateBranch()}\r\n")
        sb.append("Max-Forwards: 70\r\n")
        sb.append("From: <$scheme:$fromUser@$server>\r\n")
        sb.append("To: <$scheme:$targetUser@$server>\r\n")
        sb.append("Call-ID: $callId\r\n")
        sb.append("CSeq: $cseq BYE\r\n")
        sb.append("Content-Length: 0\r\n\r\n")
        return sb.toString()
    }

    fun computeDigestAuth(user: String, pass: String, realm: String, nonce: String, uri: String, method: String): String {
        val ha1 = md5("$user:$realm:$pass")
        val ha2 = md5("$method:$uri")
        val response = md5("$ha1:$nonce:$ha2")
        return "Digest username=\"$user\", realm=\"$realm\", nonce=\"$nonce\", uri=\"$uri\", response=\"$response\", algorithm=MD5"
    }

    private fun md5(input: String): String {
        val md = MessageDigest.getInstance("MD5")
        val digest = md.digest(input.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}
