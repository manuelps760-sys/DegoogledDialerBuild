package org.degoogled.dialer

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Contact(val id: Long, val name: String, val number: String, val isFavorite: Boolean)
data class CallLogEntry(val id: Long, val number: String, val name: String, val type: String, val timestamp: Long, val durationSec: Int)

class ContactsDbHelper(context: Context) : SQLiteOpenHelper(context, "local_dialer_data.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE contacts (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT, " +
                    "number TEXT UNIQUE, " +
                    "is_favorite INTEGER DEFAULT 0)"
        )

        db.execSQL(
            "CREATE TABLE call_logs (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "number TEXT, " +
                    "name TEXT, " +
                    "type TEXT, " +
                    "timestamp INTEGER, " +
                    "duration INTEGER)"
        )

        db.execSQL("INSERT INTO contacts (name, number, is_favorite) VALUES ('VoIP Echo Test', '100', 1)")
        db.execSQL("INSERT INTO contacts (name, number, is_favorite) VALUES ('Support Extensions', '101', 0)")
        db.execSQL("INSERT INTO contacts (name, number, is_favorite) VALUES ('Emergency Hotspot', '911', 1)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS contacts")
        db.execSQL("DROP TABLE IF EXISTS call_logs")
        onCreate(db)
    }

    fun addContact(name: String, number: String, isFavorite: Boolean = false): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("name", name)
            put("number", number)
            put("is_favorite", if (isFavorite) 1 else 0)
        }
        return db.insertWithOnConflict("contacts", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getAllContacts(): List<Contact> {
        val list = mutableListOf<Contact>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT id, name, number, is_favorite FROM contacts ORDER BY name ASC", null)
        while (cursor.moveToNext()) {
            list.add(
                Contact(
                    cursor.getLong(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getInt(3) == 1
                )
            )
        }
        cursor.close()
        return list
    }

    fun addCallLog(number: String, name: String, type: String, durationSec: Int) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("number", number)
            put("name", name)
            put("type", type)
            put("timestamp", System.currentTimeMillis())
            put("duration", durationSec)
        }
        db.insert("call_logs", null, values)
    }

    fun getCallLogs(): List<CallLogEntry> {
        val list = mutableListOf<CallLogEntry>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT id, number, name, type, timestamp, duration FROM call_logs ORDER BY timestamp DESC LIMIT 50", null)
        while (cursor.moveToNext()) {
            list.add(
                CallLogEntry(
                    cursor.getLong(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getLong(4),
                    cursor.getInt(5)
                )
            )
        }
        cursor.close()
        return list
    }
}
