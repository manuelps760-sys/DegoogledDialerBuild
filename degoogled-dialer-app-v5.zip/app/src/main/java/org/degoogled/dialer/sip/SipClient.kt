package org.degoogled.dialer.sip

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.degoogled.dialer.PcapLogger
import org.degoogled.dialer.SipDebugManager
import org.degoogled.dialer.rtp.RtpAudioEngine
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import kotlin.concurrent.thread

/**
 * Dual Transport SIP Client supporting both SIPS (TLS socket) and plain SIP (UDP socket).
 */
class SipClient(private val context: Context) {

    private var udpSocket: DatagramSocket? = null
    private var sslSocket: SSLSocket? = null
    private var writer: PrintWriter? = null
    private var reader: BufferedReader? = null

    private var isListening = false
    private var pcapLogger: PcapLogger? = null

    var sipServer: String = "192.168.1.100"
    var sipPort: Int = 5061
    var sipUser: String = "101"
    var sipPass: String = "secret123"
    var localPort: Int = 50600

    private var cseq = 1
    private var currentCallId = ""

    var onStatusChanged: ((String) -> Unit)? = null
    var onCallConnected: (() -> Unit)? = null
    var onCallEnded: (() -> Unit)? = null

    private val handler = Handler(Looper.getMainLooper())

    fun startClient(server: String, user: String, pass: String, pcapEnabled: Boolean) {
        this.sipServer = server
        this.sipUser = user
        this.sipPass = pass
        this.sipPort = if (SipDebugManager.useTls) SipDebugManager.sipsPort else SipDebugManager.udpPort

        if (pcapEnabled) {
            pcapLogger = PcapLogger(context, "sip_debug.pcap")
        }

        thread {
            try {
                isListening = true
                if (SipDebugManager.useTls) {
                    connectTlsSocket()
                } else {
                    connectUdpSocket()
                }
                sendRegister()
            } catch (e: Exception) {
                Log.e("SipClient", "Failed to start SIP transport", e)
                notifyStatus("Transport Error: ${e.message}")
            }
        }
    }

    private fun connectTlsSocket() {
        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, null, null)
        val factory = sslContext.socketFactory

        sslSocket = (factory.createSocket(sipServer, sipPort) as SSLSocket).apply {
            enabledProtocols = arrayOf("TLSv1.2", "TLSv1.3")
            startHandshake()
        }

        writer = PrintWriter(sslSocket!!.outputStream, true)
        reader = BufferedReader(InputStreamReader(sslSocket!!.inputStream))

        notifyStatus("🔒 SIPS (TLS 1.3) Handshake Established")
        startTlsListening()
    }

    private fun connectUdpSocket() {
        if (udpSocket == null || udpSocket!!.isClosed) {
            udpSocket = DatagramSocket(localPort)
        }
        notifyStatus("UDP Socket Opened on Port $localPort")
        startUdpListening()
    }

    private fun startTlsListening() {
        thread {
            try {
                var line: String?
                val responseBuilder = StringBuilder()
                while (isListening && reader != null) {
                    line = reader?.readLine()
                    if (line == null) break
                    responseBuilder.append(line).append("\r\n")
                    if (line.isEmpty()) {
                        val fullMessage = responseBuilder.toString()
                        pcapLogger?.logPacket(fullMessage.toByteArray(), fullMessage.length, sipServer, sipPort)
                        handleIncomingSipMessage(fullMessage)
                        responseBuilder.clear()
                    }
                }
            } catch (e: Exception) {
                if (isListening) Log.e("SipClient", "TLS Listener error", e)
            }
        }
    }

    private fun startUdpListening() {
        thread {
            val buffer = ByteArray(4096)
            while (isListening && udpSocket != null && !udpSocket!!.isClosed) {
                try {
                    val packet = DatagramPacket(buffer, buffer.size)
                    udpSocket!!.receive(packet)
                    val msg = String(packet.data, 0, packet.length)
                    pcapLogger?.logPacket(packet.data, packet.length, packet.address.hostAddress ?: "", packet.port)
                    handleIncomingSipMessage(msg)
                } catch (e: Exception) {
                    if (isListening) Log.e("SipClient", "UDP Listener error", e)
                }
            }
        }
    }

    fun sendRegister() {
        currentCallId = SipMessage.generateCallId()
        val registerReq = SipMessage.buildRegister(
            sipServer, sipUser, getLocalIpAddress(), localPort, currentCallId, cseq++,
            useTls = SipDebugManager.useTls
        )
        sendMessage(registerReq)
        notifyStatus("REGISTER Sent (${if (SipDebugManager.useTls) "SIPS/TLS" else "UDP"})...")
    }

    fun makeCall(targetNumber: String, codecPt: Int) {
        currentCallId = SipMessage.generateCallId()
        val rtpPort = 10000 + (100..9000).random()
        val inviteReq = SipMessage.buildInvite(
            sipServer, targetNumber, sipUser, getLocalIpAddress(), localPort, rtpPort, currentCallId, cseq++, codecPt,
            useTls = SipDebugManager.useTls, useSrtp = SipDebugManager.useSrtp
        )
        sendMessage(inviteReq)
        notifyStatus("INVITE Sent to $targetNumber (${if (SipDebugManager.useSrtp) "SRTP Encrypted" else "RTP"})...")
    }

    fun hangupCall() {
        val byeReq = SipMessage.buildBye(
            sipServer, "102", sipUser, getLocalIpAddress(), localPort, currentCallId, cseq++,
            useTls = SipDebugManager.useTls
        )
        sendMessage(byeReq)
        RtpAudioEngine.stopAudio()
        notifyStatus("BYE Sent. Call Terminated.")
        handler.post { onCallEnded?.invoke() }
    }

    private fun handleIncomingSipMessage(msg: String) {
        Log.d("SipClient", "SIP Received:\n$msg")

        if (msg.contains("SIP/2.0 200 OK")) {
            if (msg.contains("CSeq: $cseq REGISTER") || msg.contains("REGISTER")) {
                notifyStatus("Registered (200 OK) [${if (SipDebugManager.useTls) "SIPS/TLS" else "UDP"}]")
            } else if (msg.contains("INVITE")) {
                notifyStatus("Call Connected (200 OK)")
                val ack = SipMessage.buildAck(sipServer, "102", sipUser, getLocalIpAddress(), localPort, currentCallId, cseq, SipDebugManager.useTls)
                sendMessage(ack)
                
                // Start Encrypted SRTP / RTP Media Audio Stream
                RtpAudioEngine.startAudio(sipServer, 10002, SipDebugManager.selectedCodecPayloadType, SipDebugManager.useSrtp)
                handler.post { onCallConnected?.invoke() }
            }
        } else if (msg.contains("SIP/2.0 401 Unauthorized") || msg.contains("SIP/2.0 407 Proxy Authentication Required")) {
            notifyStatus("Authentication Required (401/407)")
            val realm = parseHeader(msg, "realm=\"")
            val nonce = parseHeader(msg, "nonce=\"")
            val scheme = if (SipDebugManager.useTls) "sips" else "sip"
            val authHeader = SipMessage.computeDigestAuth(sipUser, sipPass, realm, nonce, "$scheme:$sipServer", "REGISTER")
            val authRegister = SipMessage.buildRegister(sipServer, sipUser, getLocalIpAddress(), localPort, currentCallId, cseq++, authHeader, SipDebugManager.useTls)
            sendMessage(authRegister)
        } else if (msg.contains("SIP/2.0 180 Ringing")) {
            notifyStatus("180 Ringing...")
        } else if (msg.contains("BYE")) {
            notifyStatus("Call Terminated by Remote (BYE)")
            RtpAudioEngine.stopAudio()
            handler.post { onCallEnded?.invoke() }
        }
    }

    private fun parseHeader(msg: String, key: String): String {
        val idx = msg.indexOf(key)
        if (idx == -1) return ""
        val start = idx + key.length
        val end = msg.indexOf("\"", start)
        return if (end != -1) msg.substring(start, end) else ""
    }

    private fun sendMessage(text: String) {
        thread {
            try {
                if (SipDebugManager.useTls && writer != null) {
                    writer?.print(text)
                    writer?.flush()
                    pcapLogger?.logPacket(text.toByteArray(), text.length, sipServer, sipPort)
                } else if (udpSocket != null && !udpSocket!!.isClosed) {
                    val bytes = text.toByteArray()
                    val addr = InetAddress.getByName(sipServer)
                    val packet = DatagramPacket(bytes, bytes.size, addr, sipPort)
                    udpSocket?.send(packet)
                    pcapLogger?.logPacket(bytes, bytes.size, sipServer, sipPort)
                }
            } catch (e: Exception) {
                Log.e("SipClient", "Send SIP message error", e)
            }
        }
    }

    private fun getLocalIpAddress(): String {
        return "127.0.0.1"
    }

    private fun notifyStatus(status: String) {
        handler.post { onStatusChanged?.invoke(status) }
    }

    fun stopClient() {
        isListening = false
        pcapLogger?.close()
        try {
            sslSocket?.close()
            udpSocket?.close()
        } catch (e: Exception) {
            // Cleanup
        }
    }
}
