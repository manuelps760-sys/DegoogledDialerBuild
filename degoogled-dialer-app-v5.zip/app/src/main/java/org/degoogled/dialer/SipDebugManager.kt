package org.degoogled.dialer

/**
 * Singleton State & Settings Manager for Developer Diagnostics, SIPS (TLS), and SRTP Security.
 */
object SipDebugManager {
    var pcapEnabled: Boolean = true
    var useTls: Boolean = true       # Default SIPS over TLS
    var useSrtp: Boolean = true      # Default Secure RTP payload encryption
    var selectedCodecPayloadType: Int = 0 // 0 = PCMU, 8 = PCMA
    var simulatedSipErrorCode: Int = 0 // 0 = None, 404, 486, 503
    var sipsPort: Int = 5061
    var udpPort: Int = 5060
}
