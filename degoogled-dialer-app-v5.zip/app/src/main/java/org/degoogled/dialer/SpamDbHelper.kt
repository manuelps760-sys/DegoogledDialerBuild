package org.degoogled.dialer

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Offline SQLite Database for Degoogled Caller ID & Spam Lookup.
 */
class SpamDbHelper(context: Context) : SQLiteOpenHelper(context, "local_spam.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE spam_numbers (id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT UNIQUE, reason TEXT)")
        db.execSQL("INSERT INTO spam_numbers (number, reason) VALUES ('+18005550199', 'Robocall Telemarketer')")
        db.execSQL("INSERT INTO spam_numbers (number, reason) VALUES ('+18005550188', 'IRS Phishing Scam')")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS spam_numbers")
        onCreate(db)
    }

    fun isSpam(number: String): String? {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT reason FROM spam_numbers WHERE number = ?", arrayOf(number))
        return if (cursor.moveToFirst()) {
            val reason = cursor.getString(0)
            cursor.close()
            reason
        } else {
            cursor.close()
            null
        }
    }
}
