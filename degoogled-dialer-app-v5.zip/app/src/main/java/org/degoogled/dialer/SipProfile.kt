package org.degoogled.dialer
class SipProfile(val name: String, val server: String)
