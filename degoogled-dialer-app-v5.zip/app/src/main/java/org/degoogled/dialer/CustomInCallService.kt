package org.degoogled.dialer

import android.telecom.Call
import android.telecom.InCallService
import android.util.Log

class CustomInCallService : InCallService() {

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        Log.d("InCallService", "AOSP Call Added: ${call.details.handle}")
        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                when (state) {
                    Call.STATE_RINGING -> Log.d("InCallService", "Ringing...")
                    Call.STATE_ACTIVE -> Log.d("InCallService", "Active Call Session.")
                    Call.STATE_DISCONNECTED -> Log.d("InCallService", "Disconnected.")
                }
            }
        })
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
    }
}
