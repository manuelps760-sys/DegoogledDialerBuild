package org.degoogled.dialer

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.degoogled.dialer.rtp.RtpAudioEngine

class InCallActivity : AppCompatActivity() {

    private lateinit var tvRtpMetrics: TextView
    private lateinit var btnRecord: Button
    private lateinit var btnMute: Button
    private lateinit var btnSpeaker: Button

    private lateinit var btnVoiceNormal: Button
    private lateinit var btnVoiceDeep: Button
    private lateinit var btnVoiceHelium: Button
    private lateinit var btnVoiceRobot: Button
    private lateinit var btnVoiceAnon: Button

    private val handler = Handler(Looper.getMainLooper())
    private var isUpdating = true
    private var isRecording = false
    private var isMuted = false
    private var isSpeakerOn = false

    private var callRecorder: CallRecorder? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_incall)

        tvRtpMetrics = findViewById(R.id.tvRtpMetrics)
        btnRecord = findViewById(R.id.btnRecordCall)
        btnMute = findViewById(R.id.btnMuteCall)
        btnSpeaker = findViewById(R.id.btnSpeakerCall)

        btnVoiceNormal = findViewById(R.id.btnVoiceNormal)
        btnVoiceDeep = findViewById(R.id.btnVoiceDeep)
        btnVoiceHelium = findViewById(R.id.btnVoiceHelium)
        btnVoiceRobot = findViewById(R.id.btnVoiceRobot)
        btnVoiceAnon = findViewById(R.id.btnVoiceAnon)

        callRecorder = CallRecorder(this)

        setupVoiceChangerButtons()

        btnRecord.setOnClickListener {
            if (!isRecording) {
                isRecording = true
                callRecorder?.startRecording("101")
                btnRecord.text = "Stop Recording"
                Toast.makeText(this, "Call Recording Started (.wav)", Toast.LENGTH_SHORT).show()
            } else {
                isRecording = false
                val recFile = callRecorder?.stopRecording()
                btnRecord.text = "Record Call"
                Toast.makeText(this, "Saved to: ${recFile?.name}", Toast.LENGTH_LONG).show()
            }
        }

        btnMute.setOnClickListener {
            isMuted = !isMuted
            btnMute.text = if (isMuted) "Unmute" else "Mute"
            Toast.makeText(this, if (isMuted) "Microphone Muted" else "Microphone Active", Toast.LENGTH_SHORT).show()
        }

        btnSpeaker.setOnClickListener {
            isSpeakerOn = !isSpeakerOn
            btnSpeaker.text = if (isSpeakerOn) "Earpiece" else "Speaker"
            Toast.makeText(this, if (isSpeakerOn) "Speakerphone Activated" else "Earpiece Mode", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnEndCall).setOnClickListener {
            if (isRecording) {
                callRecorder?.stopRecording()
            }
            RtpAudioEngine.stopAudio()
            finish()
        }

        startMetricsUpdate()
    }

    private fun setupVoiceChangerButtons() {
        val buttons = listOf(
            btnVoiceNormal to VoiceChanger.Mode.NORMAL,
            btnVoiceDeep to VoiceChanger.Mode.DEEP_PITCH,
            btnVoiceHelium to VoiceChanger.Mode.HELIUM_PITCH,
            btnVoiceRobot to VoiceChanger.Mode.ROBOT,
            btnVoiceAnon to VoiceChanger.Mode.ANONYMIZER
        )

        for ((btn, mode) in buttons) {
            btn.setOnClickListener {
                VoiceChanger.currentMode = mode
                updateVoiceButtonUI(mode)
                Toast.makeText(this, "Voice Effect: ${mode.label}", Toast.LENGTH_SHORT).show()
            }
        }
        updateVoiceButtonUI(VoiceChanger.currentMode)
    }

    private fun updateVoiceButtonUI(selectedMode: VoiceChanger.Mode) {
        val primaryColor = ContextCompat.getColor(this, R.color.primary_accent)
        val darkSurfaceColor = ContextCompat.getColor(this, R.color.dark_surface)
        val blackColor = ContextCompat.getColor(this, R.color.black)
        val whiteColor = ContextCompat.getColor(this, R.color.text_primary)

        val map = mapOf(
            VoiceChanger.Mode.NORMAL to btnVoiceNormal,
            VoiceChanger.Mode.DEEP_PITCH to btnVoiceDeep,
            VoiceChanger.Mode.HELIUM_PITCH to btnVoiceHelium,
            VoiceChanger.Mode.ROBOT to btnVoiceRobot,
            VoiceChanger.Mode.ANONYMIZER to btnVoiceAnon
        )

        for ((mode, btn) in map) {
            if (mode == selectedMode) {
                btn.setBackgroundColor(primaryColor)
                btn.setTextColor(blackColor)
            } else {
                btn.setBackgroundColor(darkSurfaceColor)
                btn.setTextColor(whiteColor)
            }
        }
    }

    private fun startMetricsUpdate() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (!isUpdating) return
                val codecName = if (SipDebugManager.selectedCodecPayloadType == 0) "PCMU (G.711u)" else "PCMA (G.711a)"
                val secBadge = if (SipDebugManager.useTls) "🔒 SIPS (TLS 1.3) | 🔐 SRTP (AES-128)" else "⚠️ Unencrypted UDP/RTP"
                val voiceEffect = VoiceChanger.currentMode.label

                tvRtpMetrics.text = "Security: $secBadge\nVoice Effect: $voiceEffect\nCodec: $codecName\nJitter: ${RtpAudioEngine.jitterMs} ms | Packet Loss: ${RtpAudioEngine.packetLossPct}%\nEncrypted Packets: ${RtpAudioEngine.packetsSent} | Bitrate: 64 kbps"
                handler.postDelayed(this, 1000)
            }
        }, 1000)
    }

    override fun onDestroy() {
        super.onDestroy()
        isUpdating = false
    }
}
