package org.degoogled.dialer

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import kotlin.concurrent.thread

class CallRecorder(private val context: Context) {

    private var isRecording = false
    private var outputFile: File? = null

    fun startRecording(phoneNumber: String) {
        if (isRecording) return
        isRecording = true

        val filename = "call_rec_${phoneNumber}_${System.currentTimeMillis()}.wav"
        outputFile = File(context.getExternalFilesDir("call_recordings"), filename)

        thread {
            try {
                val sampleRate = 8000
                val minBufSize = AudioRecord.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )

                val audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBufSize * 2
                )

                val fos = FileOutputStream(outputFile)
                fos.write(ByteArray(44))

                audioRecord.startRecording()
                val buffer = ByteArray(minBufSize)
                var totalBytesWritten = 0

                while (isRecording) {
                    val read = audioRecord.read(buffer, 0, buffer.size)
                    if (read > 0) {
                        fos.write(buffer, 0, read)
                        totalBytesWritten += read
                    }
                }

                audioRecord.stop()
                audioRecord.release()
                fos.close()

                writeWavHeader(outputFile!!, totalBytesWritten, sampleRate)
                Log.d("CallRecorder", "Call recording saved: ${outputFile?.absolutePath}")

            } catch (e: Exception) {
                Log.e("CallRecorder", "Error during call recording", e)
            }
        }
    }

    fun stopRecording(): File? {
        isRecording = false
        return outputFile
    }

    private fun writeWavHeader(file: File, pcmDataLength: Int, sampleRate: Int) {
        val totalDataLen = pcmDataLength + 36
        val byteRate = sampleRate * 16 * 1 / 8
        val header = ByteArray(44)

        header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte(); header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte(); header[5] = ((totalDataLen shr 8) and 0xff).toByte()
        header[6] = ((totalDataLen shr 16) and 0xff).toByte(); header[7] = ((totalDataLen shr 24) and 0xff).toByte()
        header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte(); header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte(); header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
        header[16] = 16; header[17] = 0; header[18] = 0; header[19] = 0
        header[20] = 1; header[21] = 0
        header[22] = 1; header[23] = 0
        header[24] = (sampleRate and 0xff).toByte(); header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte(); header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte(); header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte(); header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = 2; header[33] = 0
        header[34] = 16; header[35] = 0
        header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte(); header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
        header[40] = (pcmDataLength and 0xff).toByte(); header[41] = ((pcmDataLength shr 8) and 0xff).toByte()
        header[42] = ((pcmDataLength shr 16) and 0xff).toByte(); header[43] = ((pcmDataLength shr 24) and 0xff).toByte()

        val raf = java.io.RandomAccessFile(file, "rw")
        raf.seek(0)
        raf.write(header)
        raf.close()
    }
}
